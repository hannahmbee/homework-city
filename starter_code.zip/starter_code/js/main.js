$(function () {
//store user input in var city
var city = ['New York City',
			'New York',
			'NYC',
			'San Francisco',
			'SF',
			'Bay Area',
			'Los Angeles',
			'LA',
			'LAX',
			'Austin',
			'ATX',
			'Sydney',
			'SD'];
;

//listen for 'submit' event
$('#submit-btn').click(function (e) {
	event.preventDefault()

//if user submits nyc
	//.attr(set nyc background image)
	//else do nothing
	if (city = 'New York City' || 'NYC' || 'New York') {
		$('body').attr('.nyc')
}

//if user submits syd
	//.attr(set syd background image)
	//else do nothing
	if (city = 'San Francisco' || 'SF' || 'Bay Area') {
		$('body').attr('.sf')
	}

//if user submits atx
	//.attr(set atx background image)
	//else do nothing
	if (city = 'Los Angeles' || 'LA' || 'LAX') {
		$('body').attr('.la')
	}

//if user submits sf
	//.attr(set sf background image)
	//else do nothing
	if (city = 'Austin' || 'ATX') {
		$(body).attr(.atx)
	}

//if user submits la
	//.attr(set la background image)
	//else do nothing
	if (city = 'Sydney' || 'SYD') {
		$(body).attr(.syd)
	}

//reset input
$('#newEntry').val('');

});




});






